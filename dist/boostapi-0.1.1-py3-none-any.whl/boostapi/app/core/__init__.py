"""Core package."""
