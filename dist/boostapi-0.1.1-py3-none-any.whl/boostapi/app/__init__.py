"""BoostAPI app package."""
