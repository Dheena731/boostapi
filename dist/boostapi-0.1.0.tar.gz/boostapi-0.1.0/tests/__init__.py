"""Tests __init__."""
